package com.shopping.esoshop.service;



import com.shopping.esoshop.dao.Dao;

public interface IDaoService extends Dao {

}

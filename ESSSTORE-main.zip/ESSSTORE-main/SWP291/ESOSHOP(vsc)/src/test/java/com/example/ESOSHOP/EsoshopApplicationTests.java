package com.example.ESOSHOP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class EsoshopApplicationTests {

	@Test
	void contextLoads() {
		
	}

}
